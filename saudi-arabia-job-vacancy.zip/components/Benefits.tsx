import React from 'react';
import { CheckCircleIcon, CubeTransparentIcon } from '../constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const BenefitItem: React.FC<{ text: string, delay: number, animationClasses: string }> = ({ text, delay, animationClasses }) => {
    return (
        <div className={`flex items-center bg-white p-4 rounded-lg shadow-md transition-all duration-700 ${animationClasses}`} style={{transitionDelay: `${delay}ms`}}>
          <CheckCircleIcon />
          <span className="ml-3 text-lg text-gray-700">{text}</span>
        </div>
    )
};


const Benefits: React.FC = () => {
    const { ref, animationClasses } = useScrollAnimation<HTMLElement>();

  return (
    <section id="benefits" ref={ref} className="py-20 bg-white scroll-target mb-1">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className={`text-3xl md:text-4xl font-bold text-gray-800 mb-4 transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '100ms'}}>
              Comprehensive Benefits Package
            </h2>
            <p className={`text-lg text-gray-600 mb-8 transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '250ms'}}>
              We believe in taking care of our team. We provide essential benefits to ensure your comfort and well-being, allowing you to focus on your work.
            </p>
            <div className="space-y-4">
              <BenefitItem text="Free Food Provided" delay={400} animationClasses={animationClasses} />
              <BenefitItem text="Free Accommodation" delay={550} animationClasses={animationClasses} />
              <BenefitItem text="Free Transportation (Company Provided)" delay={700} animationClasses={animationClasses} />
            </div>
          </div>
          <div className="hidden lg:flex justify-center items-center">
             <div className={`relative w-96 h-96 transition-all duration-700 ${animationClasses}`} style={{transitionDelay: '300ms'}}>
                <img src="https://picsum.photos/seed/benefits/500/500" alt="Benefits" className="rounded-xl shadow-2xl object-cover w-full h-full" />
                <div className="absolute -top-8 -left-8 bg-blue-500 p-6 rounded-full text-white shadow-lg">
                    <CubeTransparentIcon />
                </div>
                 <div className="absolute -bottom-8 -right-8 bg-white p-4 rounded-lg shadow-xl text-sm w-48">
                    <p className="font-semibold text-gray-800">"A great place to build your future."</p>
                    <p className="text-gray-500 mt-1">- Happy Employee</p>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;