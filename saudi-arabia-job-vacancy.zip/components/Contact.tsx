import React, { useState } from 'react';
import { PhoneIcon } from '../constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const Contact: React.FC = () => {
  const contactNumber = '8328575654';
  const [buttonText, setButtonText] = useState('Copy Number');
  const { ref, animationClasses } = useScrollAnimation<HTMLElement>();

  const handleCopy = () => {
    navigator.clipboard.writeText(contactNumber).then(() => {
      setButtonText('Copied!');
      setTimeout(() => {
        setButtonText('Copy Number');
      }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
        setButtonText('Copy Failed');
         setTimeout(() => {
            setButtonText('Copy Number');
        }, 2000);
    });
  };

  return (
    <section id="contact" ref={ref} className="py-20 bg-gray-800 text-white scroll-target">
      <div className="container mx-auto px-6 text-center">
        <h2 className={`text-3xl md:text-4xl font-bold mb-4 transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '100ms'}}>
          Ready to Apply?
        </h2>
        <p className={`text-lg text-gray-300 max-w-2xl mx-auto mb-8 transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '250ms'}}>
          Contact us directly to apply for this exciting opportunity. We look forward to hearing from you and discussing how you can become a part of our team.
        </p>
        <div className={`inline-flex items-center bg-gray-700 rounded-lg p-4 md:p-6 shadow-lg transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '400ms'}}>
          <PhoneIcon />
          <span className="text-2xl md:text-4xl font-bold ml-4 tracking-wider text-white">
            {contactNumber}
          </span>
        </div>
        <div className={`mt-8 transition-all duration-700 ease-out ${animationClasses}`} style={{transitionDelay: '550ms'}}>
          <button
            onClick={handleCopy}
            className="bg-blue-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-blue-700 transition-all duration-300 ease-in-out shadow-lg w-48"
          >
            {buttonText}
          </button>
        </div>
      </div>
    </section>
  );
};

export default Contact;