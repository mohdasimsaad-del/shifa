import React from 'react';

const Hero: React.FC = () => {
  return (
    <section
      id="home"
      className="relative h-screen flex items-center justify-center text-white mb-1"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('https://picsum.photos/seed/construction/1920/1080')" }}
      ></div>
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative z-10 text-center px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
          <span className="reveal-holder">
            <span className="animate-reveal" style={{ animationDelay: '0.2s' }}>VACANCY</span>
          </span>
          <span className="reveal-holder ml-4">
            <span className="animate-reveal" style={{ animationDelay: '0.4s' }}>AVAILABLE</span>
          </span>
        </h1>
        <h2 className="text-2xl md:text-4xl font-light mb-6 text-gray-200">
          <span className="reveal-holder">
            <span className="animate-reveal" style={{ animationDelay: '0.6s' }}>
              Safety Officer in Saudi Arabia
            </span>
          </span>
        </h2>
        <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8 text-gray-300">
           <span className="reveal-holder">
            <span className="animate-reveal" style={{ animationDelay: '0.8s' }}>
                Join a leading general contracting company and advance your career in a dynamic environment. We are looking for a dedicated and experienced Safety Officer to join our team.
            </span>
          </span>
        </p>
         <div className="reveal-holder">
            <a
              href="#contact"
              className="bg-blue-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-blue-700 transition-transform transform hover:scale-105 duration-300 ease-in-out shadow-lg animate-reveal"
              style={{ animationDelay: '1s' }}
            >
              Learn More & Apply
            </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;