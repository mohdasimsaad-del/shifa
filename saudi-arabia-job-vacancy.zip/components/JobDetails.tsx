import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { BriefcaseIcon, BuildingOfficeIcon, MapPinIcon, IndustryIcon, ClockIcon, ChartBarIcon } from '../constants';

// A reusable component for each full-screen information section
const InfoSection: React.FC<{
  id?: string;
  icon: React.ReactNode;
  title: string;
  text: string;
  imageUrl: string;
}> = ({ id, icon, title, text, imageUrl }) => {
  const { ref, animationClasses } = useScrollAnimation<HTMLElement>();

  return (
    <section
      id={id}
      ref={ref}
      className="relative h-screen flex items-center justify-center text-white scroll-target mb-1"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url('${imageUrl}')` }}
      ></div>
      <div className="absolute inset-0 bg-black opacity-60"></div>
      <div className="relative z-10 text-center px-4">
        <div className={`transition-all duration-700 ease-out ${animationClasses}`} style={{ transitionDelay: '100ms' }}>
          <div className="mx-auto bg-white/20 backdrop-blur-sm text-white rounded-full h-24 w-24 flex items-center justify-center mb-6">
              {icon}
          </div>
        </div>
        <h2 className={`text-2xl md:text-4xl font-light mb-2 uppercase tracking-widest transition-all duration-700 ease-out ${animationClasses}`} style={{ transitionDelay: '250ms' }}>{title}</h2>
        <p className={`text-4xl md:text-6xl font-bold transition-all duration-700 ease-out ${animationClasses}`} style={{ transitionDelay: '400ms' }}>{text}</p>
      </div>
    </section>
  );
};

const JobDetails: React.FC = () => {
    const opportunityDetails = [
    {
      id: 'details', // For nav link
      icon: <BriefcaseIcon />,
      title: 'Position',
      text: 'Safety Officer',
      imageUrl: 'https://picsum.photos/seed/safety/1920/1080'
    },
    {
      icon: <BuildingOfficeIcon />,
      title: 'Company',
      text: 'NAIF OBEDULLA BINBARAK GENERAL',
      imageUrl: 'https://picsum.photos/seed/company/1920/1080'
    },
    {
      icon: <MapPinIcon />,
      title: 'Location',
      text: 'Saudi Arabia',
      imageUrl: 'https://picsum.photos/seed/saudi/1920/1080'
    },
    {
      icon: <IndustryIcon />,
      title: 'Industry',
      text: 'General Contracting',
      imageUrl: 'https://picsum.photos/seed/industry/1920/1080'
    },
    {
      icon: <ClockIcon />,
      title: 'Job Type',
      text: 'Full-Time',
      imageUrl: 'https://picsum.photos/seed/jobtype/1920/1080'
    },
    {
      icon: <ChartBarIcon />,
      title: 'Experience Level',
      text: 'Mid-Level',
      imageUrl: 'https://picsum.photos/seed/experience/1920/1080'
    }
  ];

  return (
    <>
      {opportunityDetails.map((detail, index) => (
        <InfoSection
          key={index}
          id={detail.id}
          icon={detail.icon}
          title={detail.title}
          text={detail.text}
          imageUrl={detail.imageUrl}
        />
      ))}
    </>
  );
};

export default JobDetails;